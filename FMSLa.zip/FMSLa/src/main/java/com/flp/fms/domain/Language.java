package com.flp.fms.domain;
import java.sql.Date;
public class Language {
	@Override
	public String toString() {
		return "Language [langugaeName=" + langugaeName + "]";
	}
	private long lamguageId;
	private String langugaeName;
	private Date updateDate;
	private Date deleteDate;
	public long getLamguageId() {
		return lamguageId;
	}
	public void setLamguageId(long lamguageId) {
		this.lamguageId = lamguageId;
	}
	public String getLangugaeName() {
		return langugaeName;
	}
	public void setLangugaeName(String langugaeName) {
		this.langugaeName = langugaeName;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
}
