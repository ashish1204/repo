package com.flp.fms.domain;

public enum Rating {
	A,
	UA,
	PG;
}
