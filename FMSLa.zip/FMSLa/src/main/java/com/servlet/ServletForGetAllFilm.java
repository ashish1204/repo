package com.servlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.codehaus.jackson.map.ObjectMapper;

import com.flp.fms.domain.Film;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class ServletForGetAllFilm
 */
public class ServletForGetAllFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForGetAllFilm() {
        super();
        // TODO Auto-generated constructor stub
    }

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	FilmServiceImpl fsi=new FilmServiceImpl();
	
	ArrayList<Film> al = fsi.getAllFilm();
	
	
	 ObjectMapper objectMapper = new ObjectMapper();
	 try
	 {
		 PrintWriter out = response.getWriter();
		  out.print("[");
		 for(int i=0;i<al.size();i++)
		 {
			 String writingJson=objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(al.get(i));
			 response.setContentType("application/json");
		       if(i==al.size()-1)
		       {
		        out.print(writingJson);
		        break;
		       }
		       out.print(writingJson+",");
		 
		 }
		  out.print("]");
		 
	 }
		 catch(Exception e)
		 {
			 System.out.println("Exception Occured");
		 }
	
	
}
		 	
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

